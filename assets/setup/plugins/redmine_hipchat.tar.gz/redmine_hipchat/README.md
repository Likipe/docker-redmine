HipChat Plugin for Redmine
==========================

This plugin sends messages to your HipChat room when issues are created or updated.

Setup
-----

1. Install this plugin following the standard Redmine [plugin installation guide](http://www.redmine.org/wiki/redmine/Plugins).
1. In Redmine, go to the Plugin page in the Adminstration area.
1. Select 'Configure' next to the HipChat plugin and enter the required details.
