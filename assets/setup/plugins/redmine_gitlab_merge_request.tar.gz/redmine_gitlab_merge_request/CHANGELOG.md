v0.0.3
------
* add use parent settings option

v0.0.2
------
* [BC BREAK] add model to store configuration
* add module to allow enable/disable
* add permission for setup gitlab configuration
* add permission to view "new merge request" link

v0.0.1
------

* Initial release