# Load the Redmine helper
require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')

ActiveSupport::TestCase.fixture_path=(File.expand_path(File.dirname(__FILE__)) + "/fixtures")
# ActiveSupport::TestCase.fixtures :all